import { Component, ViewChild } from '@angular/core';
import { MatTable } from '@angular/material/table';
export interface CsvData {
  ip: string;
  port: string;
  country: string;
  anonymity: string;
  type: string;
  google_passed: boolean;
}

const CSV_DATA: CsvData[] = [
  {
    ip: '176.106.255.3',
    port: '8080',
    country: 'RU',
    anonymity: 'H',
    type: '',
    google_passed: false,
  },
  {
    ip: '118.69.176.168',
    port: '8080',
    country: 'VN',
    anonymity: 'N',
    type: '!',
    google_passed: false,
  },
  {
    ip: '181.188.206.42',
    port: '999',
    country: 'EC',
    anonymity: 'N',
    type: '!',
    google_passed: false,
  },
  {
    ip: '5.188.136.52',
    port: '8080',
    country: 'UA',
    anonymity: 'N',
    type: '',
    google_passed: false,
  },
  {
    ip: '80.240.201.62',
    port: '83',
    country: 'KE',
    anonymity: 'N',
    type: '',
    google_passed: false,
  },
];
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  displayedColumns: string[] = [
    'ip',
    'port',
    'country',
    'anonymity',
    'type',
    'google_passed',
    'acciones',
  ];
  columnsToDisplay: string[] = this.displayedColumns.slice();
  data: CsvData[] = [...CSV_DATA];

  @ViewChild(MatTable)
  table!: MatTable<CsvData>;

  //añadir columna
  addColumn() {
    const randomColumn = Math.floor(
      Math.random() * this.displayedColumns.length
    );
    this.columnsToDisplay.push(this.displayedColumns[randomColumn]);
  }
  // eliminar columna
  removeColumn() {
    if (this.columnsToDisplay.length) {
      this.columnsToDisplay.pop();
    }
  }
  //añadir filas
  addData() {
    const randomElementIndex = Math.floor(Math.random() * CSV_DATA.length);
    this.data.push(CSV_DATA[randomElementIndex]);
    this.table.renderRows();
  }
  // eliminar filas
  removeData(index: number) {
    this.data.splice(index, 1);
    this.table.renderRows();
  }
}
